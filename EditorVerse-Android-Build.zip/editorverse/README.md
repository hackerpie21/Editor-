# EditorVerse

EditorVerse is a mobile-first resource hub for video and photo editors.

## Included
- React/Vite frontend with navy, electric-blue, and metallic accents
- Express REST API
- SQLite database initialization (users, resources, bookmarks, comments)
- Search and category filtering
- Resource upload endpoint (development local disk)
- Bookmark endpoint and sample resource seeding

## Run locally
Requires Node.js 20+.

1. `npm install`
2. Copy `.env.example` to `.env`
3. `npm run dev`
4. Open the Vite URL printed in the terminal. API runs on port 4000 by default.

## API
- `GET /api/health`
- `GET /api/categories`
- `GET /api/resources?q=&category=`
- `GET /api/resources/:id`
- `POST /api/resources` multipart form fields: title, category, description, creator, optional file
- `POST /api/resources/:id/bookmark` JSON: `{ "username": "guest" }`
- `GET /api/users/:username`

## Before public deployment
This is a development starter, not production-ready. Add authentication/authorization, rate limiting, malware scanning, content-signature validation, cloud object storage, production database migrations/backups, logging, and restrictive CORS. Never commit a real `.env` or secrets.
